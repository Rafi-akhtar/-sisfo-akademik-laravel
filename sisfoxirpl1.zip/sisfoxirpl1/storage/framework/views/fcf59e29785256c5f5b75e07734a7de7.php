<?php $__env->startSection('title', 'Tambah Mata Pelajaran'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">Tambah Mata Pelajaran</h1>

    <div class="card shadow mb-4">
        <div class="card-body">
            <form action="<?php echo e(route('mapel.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label>Kode Mapel</label>
                    <input type="text" name="kode_mapel" class="form-control" placeholder="Contoh: MP-PWPB" required>
                </div>
                <div class="form-group">
                    <label>Nama Mata Pelajaran</label>
                    <input type="text" name="nama_mapel" class="form-control" placeholder="Contoh: Pemrograman Web" required>
                </div>
                <div class="form-group">
                    <label>KKM Minimum</label>
                    <input type="number" name="kkm" class="form-control" placeholder="Contoh: 75" required>
                </div>
                <button type="submit" class="btn btn-primary">Simpan</button>
                <a href="<?php echo e(route('mapel.index')); ?>" class="btn btn-secondary">Kembali</a>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\User\Downloads\sisfoSOALSUBMISSION\sisfoxirpl1\resources\views/mapel/create.blade.php ENDPATH**/ ?>