<?php $__env->startSection('title', 'Edit Data Kelas'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">Edit Data Kelas</h1>

    <div class="card shadow mb-4">
        <div class="card-body">
            <form action="<?php echo e(route('kelas.update', $kela->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label>Nama Kelas</label>
                    <input type="text" name="nama_kelas" class="form-control" value="<?php echo e($kela->nama_kelas); ?>" required>
                </div>
                <div class="form-group">
                    <label>Tingkat</label>
                    <input type="text" name="tingkat" class="form-control" value="<?php echo e($kela->tingkat); ?>" required>
                </div>
                <div class="form-group">
                    <label>Jurusan</label>
                    <input type="text" name="jurusan" class="form-control" value="<?php echo e($kela->jurusan); ?>" required>
                </div>
                <div class="form-group">
                    <label>Tahun Ajaran</label>
                    <input type="text" name="tahun_ajaran" class="form-control" value="<?php echo e($kela->tahun_ajaran); ?>" required>
                </div>
                <button type="submit" class="btn btn-primary">Perbarui</button>
                <a href="<?php echo e(route('kelas.index')); ?>" class="btn btn-secondary">Kembali</a>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\User\Downloads\sisfoSOALSUBMISSION\sisfoxirpl1\resources\views/kelas/edit.blade.php ENDPATH**/ ?>