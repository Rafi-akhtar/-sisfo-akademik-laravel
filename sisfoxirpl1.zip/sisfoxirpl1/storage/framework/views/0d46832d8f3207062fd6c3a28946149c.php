<?php $__env->startSection('title', 'Edit Nilai Siswa'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">Edit Nilai Siswa</h1>

    <div class="card shadow mb-4">
        <div class="card-body">
            <form action="<?php echo e(route('nilai.update', $nilai->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label>Pilih Siswa</label>
                    <select name="siswa_id" class="form-control" required>
                        <?php $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($s->id); ?>" <?php echo e($nilai->siswa_id == $s->id ? 'selected' : ''); ?>><?php echo e($s->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Pilih Mata Pelajaran</label>
                    <select name="mapel_id" class="form-control" required>
                        <?php $__currentLoopData = $mapels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($m->id); ?>" <?php echo e($nilai->mapel_id == $m->id ? 'selected' : ''); ?>><?php echo e($m->nama_mapel); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Nilai Tugas (Bobot 30%)</label>
                    <input type="number" step="0.01" name="nilai_tugas" class="form-control" value="<?php echo e($nilai->nilai_tugas); ?>" required>
                </div>
                <div class="form-group">
                    <label>Nilai UTS (Bobot 30%)</label>
                    <input type="number" step="0.01" name="nilai_uts" class="form-control" value="<?php echo e($nilai->nilai_uts); ?>" required>
                </div>
                <div class="form-group">
                    <label>Nilai UAS (Bobot 40%)</label>
                    <input type="number" step="0.01" name="nilai_uas" class="form-control" value="<?php echo e($nilai->nilai_uas); ?>" required>
                </div>
                <button type="submit" class="btn btn-primary">Perbarui & Hitung Ulang</button>
                <a href="<?php echo e(route('nilai.index')); ?>" class="btn btn-secondary">Kembali</a>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\User\Downloads\sisfoSOALSUBMISSION\sisfoxirpl1\resources\views/nilai/edit.blade.php ENDPATH**/ ?>