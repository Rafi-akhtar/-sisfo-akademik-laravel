<?php

use App\Http\Controllers\DashboardController;

use Illuminate\Support\Facades\Route;

// Route Halaman Dashboard
Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
Route::get('/home', [DashboardController::class, 'index'])->name('home');

// TODO: Buatlah Route Resource untuk Master Data Kelas
Route::resource('kelas', App\Http\Controllers\KelasController::class);

// TODO: Buatlah Route Resource untuk Master Data Siswa
Route::resource('siswa', App\Http\Controllers\SiswaController::class);

// TODO: Buatlah Route Resource untuk Master Data Guru
Route::resource('guru', App\Http\Controllers\GuruController::class);

// TODO: Buatlah Route Resource untuk Master Data Mata Pelajaran (Mapel)
Route::resource('mapel', App\Http\Controllers\MapelController::class);

// TODO: Buatlah Route Resource untuk Data Nilai Akademik
Route::resource('nilai', App\Http\Controllers\NilaiController::class);

Route::post('/logout', function () {
    return redirect('/');
})->name('logout');


