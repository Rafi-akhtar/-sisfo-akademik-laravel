<?php

namespace App\Http\Controllers;

use App\Models\Guru;
use Illuminate\Http\Request;

class GuruController extends Controller
{
    public function index()
    {
        // TODO: Ambil semua data guru dan tampilkan ke view 'guru.index'
        $gurus = \App\Models\Guru::all();
    return view('guru.index', compact('gurus'));
    }

    public function create()
    {
        // TODO: Tampilkan form tambah data guru di view 'guru.create'
        return view('guru.create');
    }

    public function store(Request $request)
    {
        // TODO: Validasi input (nip, nama, jenis_kelamin, email, no_hp, alamat) lalu simpan data guru baru
    $request->validate([
        'nip' => 'required',
        'nama' => 'required',
    ]);

    \App\Models\Guru::create($request->all());
    return redirect()->route('guru.index')->with('success', 'Data guru berhasil ditambahkan.');
    
    }

    public function edit(Guru $guru)
    {
        // TODO: Tampilkan form edit data guru di view 'guru.edit'
        return view('guru.edit', compact('guru'));
    }

    public function update(Request $request, Guru $guru)
    {
        // TODO: Validasi input lalu perbarui data guru
        $request->validate([
        'nip' => 'required',
        'nama' => 'required',
    ]);

    $guru->update($request->all());
    return redirect()->route('guru.index')->with('success', 'Data guru berhasil diperbarui.');
    }

    public function destroy(Guru $guru)
    {
        // TODO: Hapus data guru yang dipilih
        $guru->delete();
    return redirect()->route('guru.index')->with('success', 'Data guru berhasil dihapus.');
    }
}

