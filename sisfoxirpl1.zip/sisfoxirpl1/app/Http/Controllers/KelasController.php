<?php

namespace App\Http\Controllers;

use App\Models\Kelas;
use Illuminate\Http\Request;

class KelasController extends Controller
{
    public function index()
    {
        // TODO: Ambil semua data kelas beserta jumlah siswa (withCount 'siswas') dan tampilkan ke view 'kelas.index'
        $kelas = \App\Models\Kelas::withCount('siswas')->get();
    return view('kelas.index', compact('kelas'));
    }

    public function create()
    {
        // TODO: Tampilkan form tambah data kelas di view 'kelas.create'
        return view ('kelas.create');
    }

    public function store(Request $request)
    {
        // TODO: Validasi input (nama_kelas, tingkat, jurusan, tahun_ajaran) lalu simpan data kelas baru
        $request->validate([
        'nama_kelas' => 'required',
        'tingkat' => 'required',
        'jurusan' => 'required',
        'tahun_ajaran' => 'required',
    ]);

    \App\Models\Kelas::create($request->all());
    return redirect()->route('kelas.index')->with('success', 'Data kelas berhasil ditambahkan.');
    }

    public function edit(Kelas $kela)
    {
        // TODO: Tampilkan form edit data kelas di view 'kelas.edit'
        return view('kelas.edit', compact('kela'));
    }

    public function update(Request $request, Kelas $kela)
    {
        // TODO: Validasi input lalu perbarui data kelas
        $request->validate([
        'nama_kelas' => 'required',
        'tingkat' => 'required',
        'jurusan' => 'required',
        'tahun_ajaran' => 'required',
    ]);

    $kela->update($request->all());
    return redirect()->route('kelas.index')->with('success', 'Data kelas berhasil diperbarui.');
    }

    public function destroy(Kelas $kela)
    {
        // TODO: Hapus data kelas yang dipilih
        $kela->delete();
    return redirect()->route('kelas.index')->with('success', 'Data kelas berhasil dihapus.');
    }
}

