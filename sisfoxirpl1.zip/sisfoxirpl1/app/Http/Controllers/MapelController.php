<?php

namespace App\Http\Controllers;

use App\Models\Mapel;
use Illuminate\Http\Request;

class MapelController extends Controller
{
    public function index()
    {
        // TODO: Ambil semua data mata pelajaran dan tampilkan ke view 'mapel.index'
        $mapels = \App\Models\Mapel::all();
        return view('mapel.index', compact('mapels'));
    }

    public function create()
    {
        // TODO: Tampilkan form tambah data mata pelajaran di view 'mapel.create'
        return view ('mapel.create');
    }

    public function store(Request $request)
    {
        // TODO: Validasi input (kode_mapel, nama_mapel, kkm) lalu simpan data mata pelajaran baru
        $request->validate([
        'kode_mapel' => 'required',
        'nama_mapel' => 'required',
        'kkm' => 'required|numeric',
    ]);

    \App\Models\Mapel::create($request->all());
    return redirect()->route('mapel.index')->with('success', 'Data mata pelajaran berhasil ditambahkan.');
    }

    public function edit(Mapel $mapel)
    {
        // TODO: Tampilkan form edit data mata pelajaran di view 'mapel.edit'
        return view('mapel.edit', compact('mapel'));
    }

    public function update(Request $request, Mapel $mapel)
    {
        // TODO: Validasi input lalu perbarui data mata pelajaran
        $request->validate([
        'kode_mapel' => 'required',
        'nama_mapel' => 'required',
        'kkm' => 'required|numeric',
    ]);

    $mapel->update($request->all());
    return redirect()->route('mapel.index')->with('success', 'Data mata pelajaran berhasil diperbarui.');
    }

    public function destroy(Mapel $mapel)
    {
        // TODO: Hapus data mata pelajaran yang dipilih
        $mapel->delete();
    return redirect()->route('mapel.index')->with('success', 'Data mata pelajaran berhasil dihapus.');
    }
}

